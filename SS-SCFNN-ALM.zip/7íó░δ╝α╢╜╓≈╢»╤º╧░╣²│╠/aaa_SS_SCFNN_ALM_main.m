% 程序：SSL、AL，半监督学习，主动学习，高斯回归模型，距离度量准则，核k-means聚类
%数据处理
%% 清空
clc;
clear all; %清除工作空间的所有变量，函数，和MEX文件
close all; %关闭所有的Figure窗口
rand('seed',100);
%% 加载4000个数据
Data=xlsread('4000.xlsx');
Data_number=4000;
Data=Data(1:Data_number,:)'; %取4000个数据
Data_dim=size(Data,1);
%% 数据准备
%小波包去噪
for i=1:Data_dim
    [thr,sorh,keepapp,crit]=ddencmp('den','wp',Data(i,:));
    Data_new(i,:)=wpdencmp(Data(i,:),sorh,5,'sym8',crit,thr,keepapp);
end
%% 数据分有标签和无标签数据集
% 对有标签样本分配训练测试集
All_samples = 1:Data_number;  %全部样本的序号为1:4000
step = 2;%间隔1个取1个样本，取2000个样本做有标签，剩余2000个样本做无标签
labeled_indices = downsample(All_samples,step,0);  %测试集从1号开始，1,5，9，...,1993,1997
% 构造训练集的索引，使用setdiff函数来找出不在测试集索引中的元素，这些就是训练集的索引
Unlabeled_indices = setdiff(All_samples, labeled_indices);  
DataWithLabel=Data_new(:,labeled_indices);  %有标签数据集
DataWithoutLabel=Data_new(:,Unlabeled_indices);  %无标签数据集
DataWithLabel_SamInNoSelect=DataWithLabel(1:Data_dim-1,:); %有标签数据集的输入数据
DataWithLabel_SamOutNoSelect=DataWithLabel(Data_dim,:);  %有标签数据集的输出数据
DataWithoutLabel_SamInNoSelect=DataWithoutLabel(1:Data_dim-1,:); %无标签数据集的输入数据
DataWithoutLabel_SamOutNoSelect=DataWithoutLabel(Data_dim,:);  %无标签数据集的输出数据
% 对有标签样本分配训练测试集
samples = 1:Data_number/2;  %有标签样本数量为2000
step = 4;%间隔4个取1个样本，总共取500个样本做测试集
test_indices = downsample(samples,step,0);  %测试集从1号开始，1,5，9，...,1993,1997
% 构造训练集的索引，使用setdiff函数来找出不在测试集索引中的元素，这些就是训练集的索引
train_indices = setdiff(samples, test_indices);  
% 获取到有标签数据的训练集和测试集，并分输入和输出进行归一化
DataWithLabel_TrainSamInN = DataWithLabel_SamInNoSelect(:,train_indices); %训练集输入
DataWithLabel_TrainSamOutN=DataWithLabel_SamOutNoSelect(train_indices);   %训练集输出
DataWithLabel_TestSamInN = DataWithLabel_SamInNoSelect(:,test_indices);   %测试集输入
DataWithLabel_TestSamOutN=DataWithLabel_SamOutNoSelect(test_indices);     %测试集输出
[DataWithLabel_TrainSamIn,WithLabel_inputps]=mapminmax(DataWithLabel_TrainSamInN,0,1);  %训练数据输入数据归一化
[DataWithLabel_TrainSamOut,WithLabel_outputps]=mapminmax(DataWithLabel_TrainSamOutN,0,1);  %训练数据输出数据归一化
DataWithLabel_TestSamIn=mapminmax('apply',DataWithLabel_TestSamInN,WithLabel_inputps); %测试数据输入归一化后
DataWithLabel_TestSamOut=mapminmax('apply',DataWithLabel_TestSamOutN,WithLabel_outputps); 
% 对无标签数据集的输入和输出进行归一化(为了算法测试，标签是存在的)
[DataWithoutLabel_TrainSamIn,WithoutLabel_inputps]=mapminmax(DataWithoutLabel_SamInNoSelect,0,1);  %训练数据输入数据归一化
[DataWithoutLabel_TrainSamOut,WithoutLabel_outputps]=mapminmax(DataWithoutLabel_SamOutNoSelect,0,1);  %训练数据输出数据归一化
%% 对有标签和无标签数据进行聚类
iteration=100; %k-means++迭代次数
cluster_num=10; %设置聚类中心个数
[centroid_1, result_1] = Clustering(DataWithLabel_TrainSamIn', 'kmeans++', cluster_num, iteration);
[centroid_2, result_2] = Clustering(DataWithoutLabel_TrainSamIn', 'kmeans++', cluster_num, iteration);

%% 计算无标签数据集的中心到有标签数据集的中心之间距离，进行累加，取累计距离大的5组无标签数据集
for i=1:cluster_num
    for  j=1:cluster_num
        distance(i,j)=pdist([centroid_2(i,:);centroid_1(j,:)],'euclidean');
    end
end
distance_sum=sum(distance,2); %按行求和
[B,index]=sort(distance_sum,'descend');
need_label_his=[];
for i=1:4   %需要1、2、3、4、5、6.。。10！！！！！！！！！！
    need_label=find(result_2==index(i));
    need_label_his=[need_label_his; need_label];
end
DataWithoutLabel_SamIn_need_label=DataWithoutLabel_TrainSamIn(:,need_label_his);  % 需要添加标签的440个样本的前8列，即输入
DataWithoutLabel_SamOut_need_label=DataWithoutLabel_TrainSamOut(:,need_label_his);   % 需要添加标签的440个样本的第9列，即标签

%% 剔除440个样本里的冗余样本
%利用高斯模型，输入为带标签的1500样本的输入和输出
gprMdl = fitrgp(DataWithLabel_TrainSamIn',DataWithLabel_TrainSamOut','KernelFunction','ardsquaredexponential','FitMethod','sr','PredictMethod','fic','Standardize',1);
[SamOut_need_label_GP,~,limit] = predict(gprMdl,DataWithoutLabel_SamIn_need_label'); %输入为被选中的无标签样本的输入
Lower=limit(:,1);Upper=limit(:,2);
%% 剔除冗余样本
%剔除标准的上限
Remove_Upper=mean(SamOut_need_label_GP)+0.3*(abs(mean(Upper))-abs(mean(Lower)));  %0.1,0.2,0.3,0.4,0.5，。。。0.9！！！！
Remove_Lower=mean(SamOut_need_label_GP)-0.3*(abs(mean(Upper))-abs(mean(Lower)));
%大于上限，小于下限的，样本保留
add_label_1=find(DataWithoutLabel_SamOut_need_label>Remove_Upper);
add_label_2=find(DataWithoutLabel_SamOut_need_label<Remove_Lower);
SamIn_add_label=DataWithoutLabel_SamIn_need_label(:,[add_label_1,add_label_2]);  % 需要添加标签的440个样本的前8列，即输入
SamOut_add_label=DataWithoutLabel_SamOut_need_label(:,[add_label_1,add_label_2]);   % 需要添加标签的440个样本的第9列，即标签
%% 将选取出的样本添加到训练集
SamIn_add=mapminmax('reverse',SamIn_add_label,WithoutLabel_inputps);
SamOut_add=mapminmax('reverse',SamOut_add_label,WithoutLabel_outputps);
ModelData_TrainSamInN=[DataWithLabel_TrainSamInN,SamIn_add];
ModelData_TrainSamOutN=[DataWithLabel_TrainSamOutN,SamOut_add];
%% 绘图
% 输入变量绘图
figure;
kk=1:length(DataWithLabel_TestSamInN);
subplot(4,1,1);
plot(kk,DataWithLabel_TestSamInN(2,:),'b-','LineWidth',1)
title('pH');
subplot(4,1,2);
plot(kk,DataWithLabel_TestSamInN(3,:),'g-','LineWidth',1)
title('DO');
ylabel('mg/L','fontname','times new roman','fontsize',10)
subplot(4,1,3);
plot(kk,DataWithLabel_TestSamInN(5,:),'k-','LineWidth',1)
title('TP');
ylabel('mg/L','fontname','times new roman','fontsize',10)
subplot(4,1,4);
plot(kk,DataWithLabel_TestSamInN(6,:),'r-','LineWidth',1)
title('TN');
xlabel('Testing samples','fontname','times new roman','fontsize',10)
ylabel('mg/L','fontname','times new roman','fontsize',10)

% 小波包去噪对比绘图
DataWithLabel_noise=Data(:,labeled_indices);  %有标签数据集
DataWithLabel_SamOutNoSelect_noise=DataWithLabel_noise(Data_dim,:);  %有标签数据集的输出数据
DataWithLabel_TestSamOutN_noise=DataWithLabel_SamOutNoSelect_noise(test_indices);  
figure;
kk=1:length(DataWithLabel_TestSamOutN_noise);
plot(kk,DataWithLabel_TestSamOutN_noise,'k-','LineWidth',1)
xlabel('Testing samples','fontsize',10)
ylabel('NH_3-N (mg/L)','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.16 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉
% ylim([0 1.5])

figure;
plot(kk,DataWithLabel_TestSamOutN,'k-','LineWidth',1)
xlabel('Testing samples','fontsize',10)
ylabel('NH_3-N (mg/L)','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.16 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉
% ylim([0 1.5])


% 测试结果作图
figure;
kk=1:length(need_label_his);
plot(kk,Lower,'b--','LineWidth',1)
hold on
plot(kk,Upper,'g--','LineWidth',1)
hold on
plot(kk,SamOut_need_label_GP,'r-','LineWidth',1)
h=legend('Lower','Upper','Predicted output');
set(h,'Box','off','fontname','times new roman','Fontsize',10);
xlabel('Unlabeled samples','fontname','times new roman','fontsize',10)
ylabel('Predicted output','fontname','times new roman','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.14 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉
xlim([0, length(need_label_his)])
% 测试结果作图
figure;
kk=1:length(need_label_his);
plot(kk,SamOut_need_label_GP,'k-','LineWidth',1)
hold on
plot(kk,Remove_Upper*ones(1,length(need_label_his)),'b--','LineWidth',1)
hold on
plot(kk,Remove_Lower*ones(1,length(need_label_his)),'g--','LineWidth',1)
h=legend('True output','Lower cut-off','Upper cut-off');
set(h,'Box','off','fontname','times new roman','Fontsize',10);
xlabel('Unlabeled samples','fontname','times new roman','fontsize',10)
ylabel('True outputs','fontname','times new roman','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.14 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉
xlim([0, length(need_label_his)])
%% 数据保存
save DataWithLabel_TrainSamInN  DataWithLabel_TrainSamInN  %有标签数据集，训练集，输入
save DataWithLabel_TrainSamOutN DataWithLabel_TrainSamOutN %有标签数据集，训练集，输出
save DataWithLabel_TestSamInN   DataWithLabel_TestSamInN   %有标签数据集，测试集，输入
save DataWithLabel_TestSamOutN  DataWithLabel_TestSamOutN  %有标签数据集，测试集，输出
save ModelData_TrainSamInN      ModelData_TrainSamInN      %添加后，有标签数据集，训练集，输入
save ModelData_TrainSamOutN     ModelData_TrainSamOutN     %添加后，有标签数据集，训练集，输出



%% 代入SS-SCFNN-ALM
TrainSamInN=ModelData_TrainSamInN;
TrainSamOutN=ModelData_TrainSamOutN;
TestSamInN=DataWithLabel_TestSamInN;
TestSamOutN=DataWithLabel_TestSamOutN;

[TrainSamIn,inputps]=mapminmax(TrainSamInN,0,1);  %训练样本输入数据归一化
[TrainSamOut,outputps]=mapminmax(TrainSamOutN,0,1);  %训练样本输出数据归一化
TestSamIn=mapminmax('apply',TestSamInN,inputps); %测试数据输入归一化后
TestSamOut=mapminmax('apply',TestSamOutN,outputps); %测试数据输出归一化后

[InDim,TrainSamNum]=size(TrainSamIn); %InDim输入维数5，TrainSamNum训练样本数
OutDim=size(TrainSamOut,1); % OutDim输出维数为1
TestSamNum=size(TestSamIn,2); %TestSamNum测试样本数

%% 参数赋值
% emax定义的最大误差；emin定义的最小误差；
% dmax调节kd允许的最大值；dmin调节kd允许的最小值；
emax=0.5;emin=0.02;dmax=1;dmin=0.05;RC=0.85;kw=1.1;
%% 预定义变量
TrainSamIn_Window=[]; %用于存放窗口内训练样本的输入
TrainSamOut_Window=[];%用于存放窗口内训练样本的输出
Center=[];         %用于存放所有的模糊规则的中心
Width=[];
RuleNum=0; % 模糊规则数
RuleNum_his=[]; %记录模糊规则数

%% 从第二个样本开始顺序学习,动态产生
for k=1:TrainSamNum %TrainSamNum为训练样本的数目
    k %动态显示迭代步数
    RuleNum_his=[RuleNum_his RuleNum]; %模糊规则从零开始增长
    TrainSamIn_Window=[TrainSamIn_Window TrainSamIn(:,k)];    %连续存储训练样本的输入量,4*k   %TrainSamIn(:,k)为第k个样本的输入，4*1
    TrainSamOut_Window=[TrainSamOut_Window TrainSamOut(k)]; %连续存储训练样本的输出量，1*k  %TrainSamOut(:,k)为第k个样本的输出，1*1
    
    if RuleNum==0  % 如果没有模糊规则的话
        %根据第一个样本建立DFNN的第一条模糊规则
        Center=TrainSamIn(:,1);%第一个样本作为中心，Center_All是4*1
        Width=ones(InDim,1); %第一条模糊规则的宽度为预设值，对于输入变量的不同维数，不同模糊规则具有不同的宽度
        RuleNum=1;
        % 根据窗口内数据，利用伪逆技术，辨识出Hermitian矩阵Q,结果参数(输出权值)Weights以及神经网络输出NetOut
        % 首先计算窗口内样本的规则层输出阵RuleUnitOutMatrix
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        % 根据规则层输出RuleUnitOut，得到回归量矩阵RegressorMatrix
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        % 根据回归量矩阵RegressorMatrix，得到Hermitian矩阵H,结果参数(输出权值)Weights
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        % 根据Q和Weights得到神经网络输出NetOut
        NetOut=Weights*RegressorMatrix;
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/OutDim); %第一个样本的RMSE为0
        % 计算第一个样本的绝对误差，用于画训练过程误差图
        Error(k)=TrainSamOut(:,k)-NetOut; %误差=样本真实输出-网络预测输出，当前样本的误差
        Error_norm(k)=sqrt(sum(Error(k).*Error(k))/OutDim); %求取当前样本的绝对误差,用于指导模糊规则的产生;对于单输出情况，e_norm(i)=abs(Error)
    else
        %计算当前第k个样本的输出，用于误差准则检查
        RuleUnitOut=[];
        RuleUnitOut=GetMeRuleUnitOut(TrainSamIn(:,k),Center,Width); %RuleUnitOut为规则层输出
        % 改进递归最小二乘算法，更新Hermitian矩阵H，输出权值Weights以及当前样本的RegressorMatrix
        [H,Weights,RegressorMatrix] = UpdateParameterRecursively(TrainSamIn,RuleUnitOut,H,Weights,TrainSamOut,k);
        
        
    end
    %计算当前第k个样本的输出，用于误差准则检查
    RuleUnitOut=[];
    RuleUnitOut=GetMeRuleUnitOut(TrainSamIn(:,k),Center,Width); %RuleUnitOut为规则层输出
    %计算第k个样本的回归向量
    Regressor=GetMeRegressorMatrix(RuleUnitOut,TrainSamIn(:,k));  %RuleUnitOut_new,如果只有1条规则，就是5*1,；2条就是10*1
    CurrentNetOut=Weights*Regressor;%NetOut为第k个样本的网络输出
    % 计算在第k个样本时，系统的误差
    Error(k)=TrainSamOut(:,k)-CurrentNetOut; %误差=样本真实输出-网络预测输出
    Error_norm(k)=sqrt(sum(Error(k).*Error(k))/(OutDim*1)); %求取当前样本的误差,用于指导模糊规则的产生;对于单输出情况，Error_norm(i)=abs(Error)
    alpha=0.95;% alpha误差的收敛常数
    ke=max(emax*alpha.^(k),emin); %动态调整ke
    
    %计算第k个样本到所有GEBF神经元中心向量的马氏距离md，用于模糊规则的完备性检查
    md=GetMeMahalanobisDistance(TrainSamIn(:,k),Center,Width);
    [md_min,md_ind]=min(md); %找到距离最小值md_min
    md_second=md;
    if RuleNum==1 %如果规则库中只有一条模糊规则，则最小的和次小值相等
        md_second_min=md_min;
    else
        md_second(md_ind)=[]; %将最小值去掉
        [md_second_min,second_ind]=min(md_second);%找到距离次小值md_second_min
    end
    beta=0.98;%beta衰减常数，调节kd
    kd=max(dmax*beta.^(k),dmin);%对kd进行动态调整

    %% 第二种情况：泛化性能不好，但满足完备性，修正宽度
    if Error_norm(k)>ke && md_min<=kd
        kr=0.98; % 宽度调整的reduced factor
        SamIn=TrainSamIn(:,k); %SamIn为当前输入样本
        % 最靠近的神经元是md_ind
        % 最不重要的维数
        ed=abs(TrainSamIn(:,k)-Center(:,md_ind)); %计算输入样本k的输入变量的与md_ind神经元对应的隶属函数之间的欧式距离
        [ed_max,ed_ind]=max(ed);
        % 根据窗口内数据辨识结果参数
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        NetOut=Weights*RegressorMatrix;
        
        %计算当前第k个样本的输出，用于误差准则检查
        RuleUnitOut=[];
        RuleUnitOut=GetMeRuleUnitOut(TrainSamIn(:,k),Center,Width); %RuleUnitOut为规则层输出
        Regressor=GetMeRegressorMatrix(RuleUnitOut,TrainSamIn(:,k));  %RuleUnitOut_new,如果只有1条规则，就是5*1,；2条就是10*1
        NetOut_k=Weights*Regressor;%NetOut为网络输出
        Error(k)=TrainSamOut(:,k)-NetOut_k; %误差=样本真实输出-网络预测输出
        Error_norm(k)=sqrt(sum(Error(k).*Error(k))/(OutDim*1)); %求取当前样本的误差,用于指导模糊规则的产生;对于单输出情况，Error_norm(i)=abs(Error)
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/(OutDim*k)); %第i个样本的RMSE
    end
    %% 规则自组织和参数自学习
    %第一种情况：泛化性能不好且不满足完备性，增长一条模糊规则
    if Error_norm(k)>ke && md_min>kd
        %现有的中心和宽度向量
        ext_Center=Center;    %没有加入端点？
        ext_Width=Width;
        diffc=ext_Center-TrainSamIn(:,k)*ones(1,RuleNum); %计算输入样本k的输入变量的第i维与对应隶属函数之间的欧式距离
        for i=1:InDim  %对输入变量的每一维分别进行处理
            cvar=abs(diffc(i,:));
            [cd_min,nmin]=min(cvar); %找出最小距离
            cd_second=cvar;
            if RuleNum==1 %如果规则库中只有一条模糊规则，则最小的和次小值 相等
                cd_second_min=cd_min;
            else
                cd_second(nmin)=[]; %将最小值去掉
                [cd_second_min,second_ind]=min(cd_second);%找到距离次小值md_second_min
            end
            km=0.4;%模糊规则相似度阈值
            if cd_min<=km %km取0.4，新增规则的第i维的AGF能够用当前AGF表示
                Center(i,RuleNum+1)=ext_Center(i,nmin);             %新增RBF神经元的中心
                Width(i,RuleNum+1)=ext_Width(i,nmin);
            else %否则，新增规则的第i维的AGF以当前样本为中心
                Center(i,RuleNum+1)=TrainSamIn(i,k);  %TrainSamIn(i,k) 为第k个样本第i维
                ko=1.2; % ko重叠因子
                Width(i,RuleNum+1)=ko*cd_min;
            end
        end
        RuleNum=size(Center,2); %增加一条模糊规则后，需要重新计算当前的模糊规则数
        % 根据窗口内数据辨识结果参数
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        NetOut=Weights*RegressorMatrix;
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/(OutDim*k)); %均方根误差，是第一个样本到目前为止系统里所有样本的RMSE

    end
    %% 模糊规则修剪
    if RuleNum>1
        matrix_r=corrcoef([RuleUnitOutMatrix;NetOut]'); %计算出规则层神经元之间、规则层与输出层之间的相关系数矩阵
        rule_output_r=matrix_r(:,end);
        matrix_U=triu(matrix_r(:,1:end-1),1); %上三角，去除了对角线
        maxvalue_matrix_U=max(max(matrix_U));  %找到矩阵中的最大值
        [aa,ab]=find(matrix_U == maxvalue_matrix_U);
        if maxvalue_matrix_U>=RC
            if matrix_r(aa(1),end)>  matrix_r(ab(1),end)
                Center(:,aa(1))=[];   %修剪掉No位置的EBF神经元，对应隶属函数层中心
                Width(:,aa(1))=[];
                RuleNum=size(Center,2);
            else
                Center(:,ab(1))=[];   %修剪掉No位置的EBF神经元，对应隶属函数层中心
                Width(:,ab(1))=[];
                RuleNum=size(Center,2);
            end
        end

        % 根据窗口内数据辨识结果参数
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        NetOut=Weights*RegressorMatrix;
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/(OutDim*k)); %第i个样本的RMSE
    end
    %% 第三种情况：泛化性能好，但不满足完备性，只需要调整模糊规则结果参数
    if Error_norm(k)<=ke && md_min>kd
                %计算第k个样本到所有GEBF神经元中心向量的马氏距离md，用于模糊规则的完备性检查
        md=GetMeMahalanobisDistance(TrainSamIn(:,k),Center,Width);
        [md_min,md_ind]=min(md); %找到距离最小值md_min
%         kw=1.01; %宽度调整的widened factor
        SamIn=TrainSamIn(:,k); %SamIn为当前输入样本
        % 最靠近的神经元是md_ind
        % 最不重要的维数
        ed=abs(TrainSamIn(:,k)-Center(:,md_ind)); %计算输入样本k的输入变量的与md_ind神经元对应的隶属函数之间的欧式距离
        [ed_max,ed_ind]=max(ed);
%         if SamIn(ed_ind)<=Center(ed_ind,md_ind)
%             Width(ed_ind,md_ind)=kw.*Width(ed_ind,md_ind);
%         end
        
        % 根据窗口内数据辨识结果参数
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        NetOut=Weights*RegressorMatrix;
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/(OutDim*k)); %均方根误差，是第一个样本到目前为止系统里所有样本的RMSE
    end
    %% 第四种情况：泛化性能好且满足完备性，只需要调整模糊规则结果参数
    if Error_norm(k)<=ke && md_min<=kd
        % 根据窗口内数据辨识结果参数
        RuleUnitOutMatrix=[];
        RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn_Window,Center,Width);
        RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn_Window); %RegressorMatrix是M行N列，M=RuleNum*(InDim+1)，N是窗口内样本数
        [H,Weights]=DeriveWeights(RegressorMatrix,TrainSamOut_Window);
        NetOut=Weights*RegressorMatrix;
        % 计算窗内训练样本的RMSE
        RMSE(k)=sqrt(sumsqr(TrainSamOut_Window-NetOut)/(OutDim*k)); %均方根误差，是第一个样本到目前为止系统里所有样本的RMSE
    end
end  
%% 训练集预测
RuleUnitOutMatrix=[]; %清空，以便训练集预测
RegressorMatrix=[];%清空，以便测试集预测
RuleUnitOutMatrix=GetMeRuleUnitOut(TrainSamIn,Center,Width);%计算全体训练样本的规则层输出RuleUnitOut
RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TrainSamIn);%计算全体训练样本的回归量RegressorMatrix
TrainNetOut=Weights*RegressorMatrix;%NetOut为网络输出
TrainNetOutN=mapminmax('reverse',TrainNetOut,outputps); %训练集输出反归一化
% TrainNetOutN=TrainNetOut; %无需反归一化
%% 计算训练集RMSE、APE、精度
TrainError=TrainSamOutN-TrainNetOutN;
TrainRMSE=sqrt(sum(TrainError.^2)/TrainSamNum);
TrainMAE=sum(abs(TrainError)./TrainSamNum);
TrainAPE=sum(abs(TrainError)./abs(TrainSamOutN))/TrainSamNum;
TrainAccuracy=sum(1-abs(TrainError./TrainSamOutN))/TrainSamNum;
TrainRMSE
TrainMAE
TrainAPE
TrainAccuracy

%% 测试集预测
RuleUnitOutMatrix=[]; %清空，以便测试集预测
RegressorMatrix=[];%清空，以便测试集预测
RuleUnitOutMatrix=GetMeRuleUnitOut(TestSamIn,Center,Width);%计算全体测试样本的规则层输出RuleUnitOut
RegressorMatrix=GetMeRegressorMatrix(RuleUnitOutMatrix,TestSamIn); %计算全体测试样本的回归量RegressorMatrix
TestNetOut=Weights*RegressorMatrix;%NetOut为网络输出
TestNetOutN=mapminmax('reverse',TestNetOut,outputps); %训练集输出反归一化
% TestNetOutN=TestNetOut; %无需反归一化

%% 计算测试集RMSE、APE、精度
TestError=TestSamOutN-TestNetOutN;
TestRMSE=sqrt(sum(TestError.^2)/TestSamNum);
TestMAE=sum(abs(TestError)./TestSamNum);
TestAPE=sum(abs(TestError)./abs(TestSamOutN))/TestSamNum;
TestAccuracy=sum(1-abs(TestError./TestSamOutN))/TestSamNum;
TestRMSE
TestMAE
TestAPE
TestAccuracy

%% 绘制曲线
%训练误差曲线
figure;
plot(RuleNum_his,'k-','LineWidth',2);
xlabel('Training samples','fontsize',10);
ylabel('Neuron number','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.16 .16 .80 .74]);  %调整 XLABLE和YLABLE不会被切掉
ylim([min(RuleNum_his) max(RuleNum_his)+1]);
xlim([0 TrainSamNum])

figure;
plot(Error,'k','LineWidth',2);
xlabel('Training samples','fontsize',10)
ylabel('Actual output error','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.16 .16 .80 .74]);  %调整 XLABLE和YLABLE不会被切掉
% ylim([-0.5 0.5])

figure;
plot(RMSE,'k-','LineWidth',2)
xlabel('Training samples','fontsize',10)
ylabel('Training RMSE','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.16 .16 .80 .74]);  %调整 XLABLE和YLABLE不会被切掉
% xlim([0 100])
%训练结果作图

figure;
plot(TrainSamOutN,'k-','LineWidth',2)
hold on
plot(TrainNetOutN,'r--','LineWidth',2)
h=legend('Real values','Forecasting output');
set(h,'Box','off','Fontsize',10);
xlabel('Training samples','fontsize',10)
ylabel('Desired and predicted outputs','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.14 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉

%测试结果作图
figure;
kk=TrainSamNum+1:TrainSamNum+TestSamNum;
plot(kk,TestSamOutN,'k-','LineWidth',2)
hold on
plot(kk,TestNetOutN,'r--.','LineWidth',2,'Markersize',5)
h=legend('Desired output','Predicted output');
set(h,'Box','off','Fontsize',10);
xlabel('Testing samples','fontsize',10)
ylabel('Desired and predicted outputs','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.14 .16 .80 .80]);  %调整 XLABLE和YLABLE不会被切掉


%测试数据误差
figure;
kk=TrainSamNum+1:TrainSamNum+TestSamNum;
plot(kk,TestError,'k-','LineWidth',2)
xlabel('Testing samples','fontsize',10)
ylabel('Prediction error','fontsize',10)
set(gcf,'Position',[100 100 320 250]);
set(gca,'Position',[.17 .16 .79 .80]);  %调整 XLABLE和YLABLE不会被切掉

% 隶属函数图形
% PlotMem(Center,Width)
RuleNum_his_SS_SCFNN_ALM=RuleNum_his;
TrainRMSE_SS_SCFNN_ALM=RMSE; %保存RMSE曲线
TestNetOutN_SS_SCFNN_ALM=TestNetOutN;
TestError_SS_SCFNN_ALM=TestError;

save RuleNum_his_SS_SCFNN_ALM   RuleNum_his_SS_SCFNN_ALM
save TrainRMSE_SS_SCFNN_ALM TrainRMSE_SS_SCFNN_ALM
save TestSamOutN TestSamOutN
save TestNetOutN_SS_SCFNN_ALM TestNetOutN_SS_SCFNN_ALM
save TestError_SS_SCFNN_ALM TestError_SS_SCFNN_ALM

%
% %保存中心和左右宽度，用于绘制每个输入变量的隶属函数
% Weights_final=reshape(Weights,InDim+1,RuleNum);  %形成矩阵形式的权重向量
% save Center      Center
% save Width_Left  Width_Left
% save Width_Right Width_Right
% save Weights_final     Weights_final




