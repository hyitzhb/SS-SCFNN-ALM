clc
clear all
close all

load Center
load Width_Left
load Width_Right

% ��1
x=0.2: 0.1: 1.4;
y11=AGF_gaussmf(x,Center(1,1),Width_Left(1,1),Width_Right(1,1));
y12=AGF_gaussmf(x,Center(1,2),Width_Left(1,2),Width_Right(1,2));
y13=AGF_gaussmf(x,Center(1,3),Width_Left(1,3),Width_Right(1,3));
y14=AGF_gaussmf(x,Center(1,4),Width_Left(1,4),Width_Right(1,4));
y15=AGF_gaussmf(x,Center(1,5),Width_Left(1,5),Width_Right(1,5));
y16=AGF_gaussmf(x,Center(1,6),Width_Left(1,6),Width_Right(1,6));
y17=AGF_gaussmf(x,Center(1,7),Width_Left(1,7),Width_Right(1,7));
y18=AGF_gaussmf(x,Center(1,8),Width_Left(1,8),Width_Right(1,8));
y19=AGF_gaussmf(x,Center(1,9),Width_Left(1,9),Width_Right(1,9));
y110=AGF_gaussmf(x,Center(1,10),Width_Left(1,10),Width_Right(1,10));
y111=AGF_gaussmf(x,Center(1,11),Width_Left(1,11),Width_Right(1,11));
y112=AGF_gaussmf(x,Center(1,12),Width_Left(1,12),Width_Right(1,12));
% y113=AGF_gaussmf(x,Center(1,13),Width_Left(1,13),Width_Right(1,13));
% y114=AGF_gaussmf(x,Center(1,14),Width_Left(1,14),Width_Right(1,14));
% % y115=AGF_gaussmf(x,Center(1,15),Width_Left(1,15),Width_Right(1,15));

figure(1);
plot(x,y11,'k-','LineWidth',1.5)
hold on
plot(x,y12,'k-','LineWidth',1.5)
hold on
plot(x,y13,'k-','LineWidth',1.5)
hold on
plot(x,y14,'k-','LineWidth',1.5)
hold on
plot(x,y15,'k-','LineWidth',1.5)
hold on
plot(x,y16,'k-','LineWidth',1.5)
hold on
plot(x,y17,'k-','LineWidth',1.5)
hold on
plot(x,y18,'k-','LineWidth',1.5)
hold on
plot(x,y19,'k-','LineWidth',1.5)
hold on
plot(x,y110,'k-','LineWidth',1.5)
hold on
plot(x,y111,'k-','LineWidth',1.5)
hold on
plot(x,y112,'k-','LineWidth',1.5)
hold on
% plot(x,y113,'k-','LineWidth',1.5)
% hold on
% plot(x,y114,'k-','LineWidth',1.5)
% hold on
% % plot(x,y115,'k-','LineWidth',1.5)
% % hold on
xlabel('Input variable x(t)') 
ylabel('Membership functions of x(t)');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.16 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([0.2 1.4])

%��2

y21=AGF_gaussmf(x,Center(2,1),Width_Left(2,1),Width_Right(2,1));
y22=AGF_gaussmf(x,Center(2,2),Width_Left(2,2),Width_Right(2,2));
y23=AGF_gaussmf(x,Center(2,3),Width_Left(2,3),Width_Right(2,3));
y24=AGF_gaussmf(x,Center(2,4),Width_Left(2,4),Width_Right(2,4));
y25=AGF_gaussmf(x,Center(2,5),Width_Left(2,5),Width_Right(2,5));
y26=AGF_gaussmf(x,Center(2,6),Width_Left(2,6),Width_Right(2,6));
y27=AGF_gaussmf(x,Center(2,7),Width_Left(2,7),Width_Right(2,7));
y28=AGF_gaussmf(x,Center(2,8),Width_Left(2,8),Width_Right(2,8));
y29=AGF_gaussmf(x,Center(2,9),Width_Left(2,9),Width_Right(2,9));
y210=AGF_gaussmf(x,Center(2,10),Width_Left(2,10),Width_Right(2,10));
y211=AGF_gaussmf(x,Center(2,11),Width_Left(2,11),Width_Right(2,11));
y212=AGF_gaussmf(x,Center(2,12),Width_Left(2,12),Width_Right(2,12));
% y213=AGF_gaussmf(x,Center(2,13),Width_Left(2,13),Width_Right(2,13));
% y214=AGF_gaussmf(x,Center(2,14),Width_Left(2,14),Width_Right(2,14));
% % y215=AGF_gaussmf(x,Center(2,15),Width_Left(2,15),Width_Right(2,15));


figure(2);
plot(x,y21,'k-','LineWidth',1.5)
hold on
plot(x,y22,'k-','LineWidth',1.5)
hold on
plot(x,y23,'k-','LineWidth',1.5)
hold on
plot(x,y24,'k-','LineWidth',1.5)
hold on
plot(x,y25,'k-','LineWidth',1.5)
hold on
plot(x,y26,'k-','LineWidth',1.5)
hold on
plot(x,y27,'k-','LineWidth',1.5)
hold on
plot(x,y28,'k-','LineWidth',1.5)
hold on
plot(x,y29,'k-','LineWidth',1.5)
hold on
plot(x,y210,'k-','LineWidth',1.5)
hold on
plot(x,y211,'k-','LineWidth',1.5)
hold on
plot(x,y212,'k-','LineWidth',1.5)
% hold on
% plot(x,y213,'k-','LineWidth',1.5)
% hold on
% plot(x,y214,'k-','LineWidth',1.5)
% hold on
% % plot(x,y215,'k-','LineWidth',1.5)
% % hold on
xlabel('Input variable x(t-6)') 
ylabel('Membership functions of x(t-6)');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.16 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([0.2 1.4])

%��3
y31=AGF_gaussmf(x,Center(3,1),Width_Left(3,1),Width_Right(3,1));
y32=AGF_gaussmf(x,Center(3,2),Width_Left(3,2),Width_Right(3,2));
y33=AGF_gaussmf(x,Center(3,3),Width_Left(3,3),Width_Right(3,3));
y34=AGF_gaussmf(x,Center(3,4),Width_Left(3,4),Width_Right(3,4));
y35=AGF_gaussmf(x,Center(3,5),Width_Left(3,5),Width_Right(3,5));
y36=AGF_gaussmf(x,Center(3,6),Width_Left(3,6),Width_Right(3,6));
y37=AGF_gaussmf(x,Center(3,7),Width_Left(3,7),Width_Right(3,7));
y38=AGF_gaussmf(x,Center(3,8),Width_Left(3,8),Width_Right(3,8));
y39=AGF_gaussmf(x,Center(3,9),Width_Left(3,9),Width_Right(3,9));
y310=AGF_gaussmf(x,Center(3,10),Width_Left(3,10),Width_Right(3,10));
y311=AGF_gaussmf(x,Center(3,11),Width_Left(3,11),Width_Right(3,11));
y312=AGF_gaussmf(x,Center(3,12),Width_Left(3,12),Width_Right(3,12));
% y313=AGF_gaussmf(x,Center(3,13),Width_Left(3,13),Width_Right(3,13));
% y314=AGF_gaussmf(x,Center(3,14),Width_Left(3,14),Width_Right(3,14));
% % y315=AGF_gaussmf(x,Center(3,15),Width_Left(3,15),Width_Right(3,15));

figure(3);
plot(x,y31,'k-','LineWidth',1.5)
hold on
plot(x,y32,'k-','LineWidth',1.5)
hold on
plot(x,y33,'k-','LineWidth',1.5)
hold on
plot(x,y34,'k-','LineWidth',1.5)
hold on
plot(x,y35,'k-','LineWidth',1.5)
hold on
plot(x,y36,'k-','LineWidth',1.5)
hold on
plot(x,y37,'k-','LineWidth',1.5)
hold on
plot(x,y38,'k-','LineWidth',1.5)
hold on
plot(x,y39,'k-','LineWidth',1.5)
hold on
plot(x,y310,'k-','LineWidth',1.5)
hold on
plot(x,y311,'k-','LineWidth',1.5)
hold on
plot(x,y312,'k-','LineWidth',1.5)
% hold on
% plot(x,y313,'k-','LineWidth',1.5)
% hold on
% plot(x,y314,'k-','LineWidth',1.5)
% hold on
% plot(x,y315,'k-','LineWidth',1.5)
% hold on

xlabel('Input variable x(t-12)') 
ylabel('Membership functions of x(t-12)');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.16 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([0.2 1.4])

%��4
y41=AGF_gaussmf(x,Center(4,1),Width_Left(4,1),Width_Right(4,1));
y42=AGF_gaussmf(x,Center(4,2),Width_Left(4,2),Width_Right(4,2));
y43=AGF_gaussmf(x,Center(4,3),Width_Left(4,3),Width_Right(4,3));
y44=AGF_gaussmf(x,Center(4,4),Width_Left(4,4),Width_Right(4,4));
y45=AGF_gaussmf(x,Center(4,5),Width_Left(4,5),Width_Right(4,5));
y46=AGF_gaussmf(x,Center(4,6),Width_Left(4,6),Width_Right(4,6));
y47=AGF_gaussmf(x,Center(4,7),Width_Left(4,7),Width_Right(4,7));
y48=AGF_gaussmf(x,Center(4,8),Width_Left(4,8),Width_Right(4,8));
y49=AGF_gaussmf(x,Center(4,9),Width_Left(4,9),Width_Right(4,9));
y410=AGF_gaussmf(x,Center(4,10),Width_Left(4,10),Width_Right(4,10));
y411=AGF_gaussmf(x,Center(4,11),Width_Left(4,11),Width_Right(4,11));
y412=AGF_gaussmf(x,Center(4,12),Width_Left(4,12),Width_Right(4,12));
% y413=AGF_gaussmf(x,Center(4,13),Width_Left(4,13),Width_Right(4,13));
% y414=AGF_gaussmf(x,Center(4,14),Width_Left(4,14),Width_Right(4,14));
% % y415=AGF_gaussmf(x,Center(4,15),Width_Left(4,15),Width_Right(4,15));

figure(4);
plot(x,y41,'k-','LineWidth',1.5)
hold on
plot(x,y42,'k-','LineWidth',1.5)
hold on
plot(x,y43,'k-','LineWidth',1.5)
hold on
plot(x,y44,'k-','LineWidth',1.5)
hold on
plot(x,y45,'k-','LineWidth',1.5)
hold on
plot(x,y46,'k-','LineWidth',1.5)
hold on
plot(x,y47,'k-','LineWidth',1.5)
hold on
plot(x,y48,'k-','LineWidth',1.5)
hold on
plot(x,y49,'k-','LineWidth',1.5)
hold on
plot(x,y410,'k-','LineWidth',1.5)
hold on
plot(x,y411,'k-','LineWidth',1.5)
hold on
plot(x,y412,'k-','LineWidth',1.5)
% hold on
% plot(x,y413,'k-','LineWidth',1.5)
% hold on
% plot(x,y414,'k-','LineWidth',1.5)
% hold on
% plot(x,y315,'k-','LineWidth',1.5)
% hold on

xlabel('Input variable x(t-18)') 
ylabel('Membership functions of x(t-18)');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.16 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([0.2 1.4])
%% �����������
(3+2+2+3)*3+(4+1)*12
