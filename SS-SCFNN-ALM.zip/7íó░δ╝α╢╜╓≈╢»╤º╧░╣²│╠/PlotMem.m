function PlotMem(Center,Width)

% ���ܣ�������������ͼ��

% ��1
x=-0.5: 0.1: 1.5;
y11=AGF_gaussmf(x,Center(1,1),Width(1,1));
y12=AGF_gaussmf(x,Center(1,2),Width(1,2));
y13=AGF_gaussmf(x,Center(1,3),Width(1,3));
y14=AGF_gaussmf(x,Center(1,4),Width(1,4));
y15=AGF_gaussmf(x,Center(1,5),Width(1,5));
y16=AGF_gaussmf(x,Center(1,6),Width(1,6));
% y17=AGF_gaussmf(x,Center(1,7),Width_Left(1,7),Width_Right(1,7));
% y18=AGF_gaussmf(x,Center(1,8),Width_Left(1,8),Width_Right(1,8));


figure;
plot(x,y11,'k-','LineWidth',1.5)
hold on
plot(x,y12,'k-','LineWidth',1.5)
hold on
plot(x,y13,'k-','LineWidth',1.5)
hold on
plot(x,y14,'k-','LineWidth',1.5)
hold on
plot(x,y15,'k-','LineWidth',1.5)
hold on
plot(x,y16,'k-','LineWidth',1.5)
% hold on
% plot(x,y17,'k-','LineWidth',1.5)
% hold on
% plot(x,y18,'k-','LineWidth',1.5)

xlabel('Input variable x(t)') 
ylabel('Membership functions');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.14 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([-0.5 1.5])

%��2
y21=AGF_gaussmf(x,Center(2,1),Width(2,1));
y22=AGF_gaussmf(x,Center(2,2),Width(2,2));
y23=AGF_gaussmf(x,Center(2,3),Width(2,3));
y24=AGF_gaussmf(x,Center(2,4),Width(2,4));
y25=AGF_gaussmf(x,Center(2,5),Width(2,5));
y26=AGF_gaussmf(x,Center(2,6),Width(2,6));
% y27=AGF_gaussmf(x,Center(2,7),Width_Left(2,7),Width_Right(2,7));
% y28=AGF_gaussmf(x,Center(2,8),Width_Left(2,8),Width_Right(2,8));

figure;
plot(x,y21,'k-','LineWidth',1.5)
hold on
plot(x,y22,'k-','LineWidth',1.5)
hold on
plot(x,y23,'k-','LineWidth',1.5)
hold on
plot(x,y24,'k-','LineWidth',1.5)
hold on
plot(x,y25,'k-','LineWidth',1.5)
hold on
plot(x,y26,'k-','LineWidth',1.5)
% hold on
% plot(x,y27,'k-','LineWidth',1.5)
% hold on
% plot(x,y27,'k-','LineWidth',1.5)

xlabel('Input variable x(t)') 
ylabel('Membership functions');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.14 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([-0.5 1.5])

%��3
y31=AGF_gaussmf(x,Center(3,1),Width(3,1));
y32=AGF_gaussmf(x,Center(3,2),Width(3,2));
y33=AGF_gaussmf(x,Center(3,3),Width(3,3));
y34=AGF_gaussmf(x,Center(3,4),Width(3,4));
y35=AGF_gaussmf(x,Center(3,5),Width(3,5));
y36=AGF_gaussmf(x,Center(3,6),Width(3,6));
% y37=AGF_gaussmf(x,Center(3,7),Width_Left(3,7),Width_Right(3,7));
% y38=AGF_gaussmf(x,Center(3,8),Width_Left(3,8),Width_Right(3,8));

figure;
plot(x,y31,'k-','LineWidth',1.5)
hold on
plot(x,y32,'k-','LineWidth',1.5)
hold on
plot(x,y33,'k-','LineWidth',1.5)
hold on
plot(x,y34,'k-','LineWidth',1.5)
hold on
plot(x,y35,'k-','LineWidth',1.5)
hold on
plot(x,y36,'k-','LineWidth',1.5)
% hold on
% plot(x,y37,'k-','LineWidth',1.5)
% hold on
% plot(x,y38,'k-','LineWidth',1.5)

xlabel('Input variable x(t)') 
ylabel('Membership functions');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.14 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([-0.5 1.5])

%��4
y41=AGF_gaussmf(x,Center(4,1),Width(4,1));
y42=AGF_gaussmf(x,Center(4,2),Width(4,2));
y43=AGF_gaussmf(x,Center(4,3),Width(4,3));
y44=AGF_gaussmf(x,Center(4,4),Width(4,4));
y45=AGF_gaussmf(x,Center(4,5),Width(4,5));
y46=AGF_gaussmf(x,Center(4,6),Width(4,6));
% y47=AGF_gaussmf(x,Center(4,7),Width_Left(4,7),Width_Right(4,7));
% y48=AGF_gaussmf(x,Center(4,8),Width_Left(4,8),Width_Right(4,8));

figure;
plot(x,y41,'k-','LineWidth',1.5)
hold on
plot(x,y42,'k-','LineWidth',1.5)
hold on
plot(x,y43,'k-','LineWidth',1.5)
hold on
plot(x,y44,'k-','LineWidth',1.5)
hold on
plot(x,y45,'k-','LineWidth',1.5)
hold on
plot(x,y46,'k-','LineWidth',1.5)
% hold on
% plot(x,y47,'k-','LineWidth',1.5)
% hold on
% plot(x,y48,'k-','LineWidth',1.5)

xlabel('Input variable x(t)') 
ylabel('Membership functions');
set(gcf,'Position',[20 40 320 250]);
set(gca,'Position',[.14 .17 .80 .74]);  %���� XLABLE��YLABLE���ᱻ�е�
xlim([-0.5 1.5])

end